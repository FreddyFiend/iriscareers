<template>
  <q-page class="q-pa-md flex flex-center row justify-center">
    <div class="" style="max-width: 800px">
      <h5>CAREER MANAGEMENT SERVICES</h5>
      <br />
      <q-expansion-item
        class="q-ma-md shadow-1 overflow-hidden"
        style="border-radius: 30px"
        icon="explore"
        label="IRIS & CAREER MANAGEMENT"
        header-class="bg-primary text-white"
        expand-icon-class="text-white"
      >
        <q-card class="q-pa-md">
          <q-card-section>
            <p>
              IRIS Career Services Chapter is envisioned to control the
              unemployment ratio around the country. Therefore, IRIS is intended
              to provide following services.
            </p>
            <ul>
              <li>
                Take account of all the unemployed people in the country and
                register them onto our portal.
              </li>
              <li>
                Where they’ll get notified for the jobs matching their skills
                and competence.
              </li>
              <li>
                IRIS will provide various technical and educational programs,
                wherein, we will tech and train people for various jobs and
                responsibilities.
              </li>
              <li>
                IRIS will also offer them opportunities to work with IRIS on
                projects suitable for their skills and knowledge as well.
              </li>
              <li>
                IRIS will arrange projects, whereby, we will acquaint people
                with various job opportunities and also entrepreneurships.
              </li>
              <li>
                IRIS will also Provide, as
                <span style="font-weight: 500">
                  CAREER MANAGEMENT SERVICES.</span
                >
              </li>
            </ul>
          </q-card-section>
        </q-card>
      </q-expansion-item>
      <q-expansion-item
        class="q-ma-md shadow-1 overflow-hidden"
        style="border-radius: 30px"
        icon="explore"
        label="Registration of Unemployed People / candidates for career management
        services"
        header-class="bg-primary text-white"
        expand-icon-class="text-white"
      >
        <q-card class="q-pa-md">
          <q-card-section
            ><p>
              Unemployment is one the major issues of Pakistan and it have even
              increased due to the ongoing Worldwide Pandemic Covid-19. Due to
              lockdowns and closure of many industries, millions of people have
              lost their jobs. Besides, a lot many people spends great deal of
              their time and energies for job searching. IRIS Career Services
              will provide you an easy solution to this problem. We’ll register
              unemployed people onto our e-portal and update them with job
              opportunities in various governmental and non-governmental
              institutions and organizations.
            </p></q-card-section
          ></q-card
        ></q-expansion-item
      >
      <q-expansion-item
        class="q-ma-md shadow-1 overflow-hidden"
        style="border-radius: 30px"
        icon="explore"
        label="Technical and Professional Programs"
        header-class="bg-primary text-white"
        expand-icon-class="text-white"
      >
        <q-card class="q-pa-md">
          <q-card-section>
            <p>
              IRIS Career Services offers you technical course with certificates
              that will help in job seeking. These professional programs will
              equip you will all required skills and qualities which will
              enhance your market value. Our competent Team of adept instructors
              will prepare you for your desired jobs in weeks. These programs
              will concoct you with desired attributes for particular job.
            </p></q-card-section
          ></q-card
        ></q-expansion-item
      >
      <q-expansion-item
        class="q-ma-md shadow-1 overflow-hidden"
        style="border-radius: 30px"
        icon="explore"
        label="Career Counseling"
        header-class="bg-primary text-white"
        expand-icon-class="text-white"
      >
        <q-card class="q-pa-md">
          <q-card-section>
            <p>
              One of the basic causes of unemployment is that majority of our
              youth is unaware of several money making careers and
              entrepreneurial ideas. And they only stick to few careers where
              competition is consequently increased due abundance of job
              applicants. IRIS Career Services has designed Career Counseling as
              its Sub-field for young people to provoke awareness about plenty
              of careers, wherein, people can make handsome amount of money and
              subsequently change their lives.
            </p>
          </q-card-section></q-card
        ></q-expansion-item
      >

      <ul class="q-ma-md">
        <li>Finding appropriate opportunities.</li>
        <li>
          Capacity Development for tests, Public service Commission
          Examinations.
        </li>
        <li>Training for job Interviews.</li>
        <li>Personality development skills.</li>
        <li>Leadership development Skills.</li>
        <li>Motivational Skills.</li>
      </ul>
    </div>
  </q-page>
</template>

<script>
import { defineComponent } from "vue";

export default defineComponent({
  name: "mycareerprofile",
});
</script>
<style lang="scss" scoped>
p {
  padding: 0.2rem;
}
h4,
h5,
h6 {
  padding-top: 1rem;
}
</style>
