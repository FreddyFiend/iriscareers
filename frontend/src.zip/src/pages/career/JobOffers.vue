<template>
  <q-page class="q-pa-md flex flex-center row justify-center"> </q-page>
</template>

<script>
import { defineComponent } from "vue";

export default defineComponent({
  name: "JobOffers",
});
</script>
<style lang="scss" scoped></style>
